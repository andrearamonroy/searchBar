package com.example.flutter_app_podcast

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
